<?php

class ProductsModel extends CI_Model{
		public function __construct(){
			parent::__construct();
			$this->load->database();
		}
		
		public function getProduct(){
			
			$sql="SELECT * FROM product";
			
			$query=$this->db->query($sql);
			return $query->result_array();
		}
		
		
		public function getCart(){
			
			$sql="SELECT * FROM cart";
			
			$query=$this->db->query($sql);
			return $query->result_array();
		}
		
		
		public function getUser(){
			
			$sql="SELECT * FROM user";
			
			$query=$this->db->query($sql);
			return $query->result_array();
		}
		
		
		
	}


