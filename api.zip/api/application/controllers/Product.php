<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';


class Product extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
		$this->load->model('ProductsModel');
		
    }

    
    function index_get() {
        $id = $this->get('product_id');
        if ($id == '') {
            $product = $this->ProductsModel->getProduct();
			
        } else {
            $this->db->where('product_id', $id);
           $product = $this->db->get('product')->result();
        }
        $this->response($product, 200);
    }


    
	function index_post() {
        $data = array(
                    'product_id'           => $this->post('product_id'),
                    'nama_product'          => $this->post('nama_product'),
                    'price'    => $this->post('price'),
					'qty'    => $this->post('qty')
					);
        $insert = $this->db->insert('product', $data);
        if ($insert) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }
	
	
	function index_put() {
        $id = $this->put('product_id');
        $data = array(
						'product_id'           => $this->put('product_id'),
						'nama_product'          => $this->put('nama_product'),
						'price'    => $this->put('price'),
						'qty'    => $this->put('qty')
					);
        $this->db->where('product_id', $id);
        $update = $this->db->update('product', $data);
        if ($update) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }
	
	function index_delete() {
        $id = $this->delete('product_id');
        $this->db->where('product_id', $id);
        $delete = $this->db->delete('product');
        if ($delete) {
            $this->response(array('status' => 'success'), 201);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }
	
	
}
