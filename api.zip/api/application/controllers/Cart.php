<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';


class Cart extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
		$this->load->model('ProductsModel');
		
    }

    
    function index_get() {
        $id = $this->get('cart_id');
        if ($id == '') {
            $cart = $this->ProductsModel->getCart();
			
        } else {
            $this->db->where('cart_id', $id);
            $cart = $this->db->get('cart')->result();
        }
        $this->response($cart, 200);
    }


    
	function index_post() {
        $data = array(
                    'cart_id'           => $this->post('cart_id'),
                    'user_id'          => $this->post('user_id'),
                    'product_id'    => $this->post('product_id'),
					'cart_qty'    => $this->post('cart_qty')
					);
        $insert = $this->db->insert('cart', $data);
        if ($insert) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }
	
	
	function index_put() {
        $id = $this->put('cart_id');
        $data = array(
						'cart_id'           => $this->put('cart_id'),
						'user_id'          => $this->put('user_id'),
						'product_id'    => $this->put('product_id'),
						'cart_qty'    => $this->put('cart_qty')
					);
        $this->db->where('cart_id', $id);
        $update = $this->db->update('cart', $data);
        if ($update) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }
	
	function index_delete() {
        $id = $this->delete('cart_id');
        $this->db->where('cart_id', $id);
        $delete = $this->db->delete('cart');
        if ($delete) {
            $this->response(array('status' => 'success'), 201);
        } else {
            $this->response(array('status' => 'fail', 502));
        }
    }
	
	
}
